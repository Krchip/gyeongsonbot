//유료결제를 통한 기능제공
const Discord = require("discord.js");
const { sendDenied, sendError } = require("../util/embed");

module.exports = {
    name: "로샵공지",
    description: "로샵공지 커맨드",
    excute(client, message, args) {
        if (message.author.bot) return;

        if (message.guild.id === "761897446410027010") {
            if (!message.member.hasPermission("MANAGE_MESSAGES")) return sendDenied(message.channel);

            let contents = message.content.slice("경손아 로샵공지 ".length);
            let embed2 = new Discord.MessageEmbed();
            let embed = new Discord.MessageEmbed();
            embed.setTitle("Public Roblox Shop 공지 서비스");
            embed.setColor("#0059C4");
            embed.setDescription(contents);
            embed.setFooter(`${message.author.tag} 이 작성함`, message.author.displayAvatarURL());
            embed.setTimestamp();

            embed2.setTitle("다음과 같이 공지가 전송되었어요.");
            embed2.setDescription(contents);
            embed2.setColor("#0059C4");
            embed2.setFooter(`${message.author.tag} 이 작성함`, message.author.displayAvatarURL());
            embed2.setTimestamp();

            message.reply(embed2);
            client.channels.cache.get("761981446058410035").send(embed);
            message.react("✅");
        }
    },
};
