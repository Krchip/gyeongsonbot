const Discord = require("discord.js");

module.exports = {
    name: "hellothisisverification",
    description: "코리안봇 인증 커맨드",
    excute(_, message) {
        message.channel.send("Chip_#8346");
    },
};
